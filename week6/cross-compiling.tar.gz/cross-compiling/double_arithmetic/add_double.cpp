#include "double_arithmetic.h"

double add_double(double num1, double num2)
{
    return num1 + num2;
}
