#ifndef INT_ARITHMETIC_H
#define INT_ARITHMETIC_H

#ifdef __cplusplus
extern "C"
{
#endif
    int add_int(int num1, int num2);
    int subtract_int(int num1, int num2);
    int multiply_int(int num1, int num2);
    int divide_int(int num1, int num2);
#ifdef __cplusplus
}
#endif

#endif // INT_ARITHMETIC_H
