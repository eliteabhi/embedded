#include "int_arithmetic.h"

int subtract_int(int num1, int num2)
{
    return num1 - num2;
}
