#include "int_arithmetic.h"

int multiply_int(int num1, int num2)
{
    return num1 * num2;
}
