#!/bin/bash

source ./envsetup.sh 

exec "$@"

