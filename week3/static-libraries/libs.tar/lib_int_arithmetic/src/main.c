#include "../lib/int_arithmetic.h"
#include <stdio.h>
int main() {

    printf( "%d\n", add(2, 2) );
    printf( "%d\n", sub(2, 2) );
    printf( "%d\n", mul(2, 2) );
    printf( "%d\n", div(2, 2) );

    return 0;

}
