#include "float_arithmetic.h"

float f_add( float a, float b ) { return a + b; }