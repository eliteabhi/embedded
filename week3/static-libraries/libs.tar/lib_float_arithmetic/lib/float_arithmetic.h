
#ifdef __cplusplus

    extern "C" {

#endif

    float f_add(float a, float b);
    float f_sub(float a, float b);
    float f_mul(float a, float b);
    float f_div(float a, float b);

#ifdef __cplusplus

    }

#endif