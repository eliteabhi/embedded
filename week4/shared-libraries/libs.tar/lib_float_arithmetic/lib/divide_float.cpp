#include "float_arithmetic.h"

float f_div( float a, float b ) { return a / b; }