#include "int_arithmetic.h"

int mul( int a, int b ) { return a * b; }